#!/bin/bash
ANIMALS="man bear pig dog cat sheep"
for ANIMAL in $ANIMALS
  do
    echo $ANIMAL
  done