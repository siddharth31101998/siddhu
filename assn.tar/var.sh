#!/bin/bash
My_var = "Shell scripting is fun!"
echo = "$My_var"