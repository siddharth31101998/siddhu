#!/bin/bash

#Write a shell script that prints "Shell Scripting is Fun!" to the screen.

echo “Shell Scripting is Fun!”